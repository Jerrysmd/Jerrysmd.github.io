+++
title = "About"
description = ""
date = "2020-10-01"
aliases = []
author = "JiaRui liu"

+++
# Jerry Liu / 刘佳锐
---
+ ☎️&nbsp;Phone：+86 15735184098
+ 📬&nbsp;E-mail：0x004c2@gmail.com
+ 📖&nbsp;B l o g：https://jerrysmd.github.io/

## 🎓 Education

+ Bachelor：       2015 - 2019&nbsp;&nbsp;&nbsp;&nbsp;山西大学 / 软件工程专业
+ Exchange student：2019 - 2020&nbsp;&nbsp;&nbsp;&nbsp;Texas A&M University
