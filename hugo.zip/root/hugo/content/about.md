+++
title = "About"
description = ""
date = "2020-10-01"
aliases = []
author = "JiaRui liu"

+++
# JIARUI LIU
---
+ ☎️&nbsp;Phone：+86 15735184098
+ 📬&nbsp;E-mail：0x004c2@gmail.com
+ 📖&nbsp;B l o g：[jerrysmd.github.io/categories/technology/](https://jerrysmd.github.io/categories/technology/)

## 🎓 Education

+ Bachelor：       2015 - 2019&nbsp;&nbsp;&nbsp;&nbsp;Shanxi University / Software Engineering
+ Exchange student：2019 - 2020&nbsp;&nbsp;&nbsp;&nbsp;Texas A&M University
