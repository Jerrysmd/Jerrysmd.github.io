---
title: "Data Warehouse: Real-Time" # Title of the blog post.
date: 2021-03-08T10:40:49+08:00 # Date of post creation.
description: "" # Description used for search engine.
featured: true # Sets if post is a featured post, making appear on the home page side bar.
draft: false # Sets whether to render this page. Draft of true will not be rendered.
toc: true # Controls if a table of contents should be generated for first-level links automatically.
# menu: main
# thumbnail: "images/.png" # Sets thumbnail image appearing inside card on homepage.
# featureImage: "/images/path/file.jpg" # Sets featured image on blog post.
# featureImageAlt: 'Description of image' # Alternative text for featured image.
# featureImageCap: 'This is the featured image.' # Caption (optional).
codeLineNumbers: true # Override global value for showing of line numbers within code block.
codeMaxLines: 40 # Override global value for how many lines within a code block before auto-collapsing.
codeLineNumbers: true # Override global value for showing of line numbers within code block.
figurePositionShow: true # Override global value for showing the figure label.
categories:
  - Technology
tags:
  - datawarehouse
  - distribution
  - flink
comments: true # Disable comment if false.

---

Data warehouse is a system that pulls together data derived from operational systems and external data sources within an organization for reporting and analysis. A data warehouse is a central repository of information that provides users with current and historical decision support information.

<!--more-->

## ODS 数据采集层

原始数据，日志和业务数据

### 日志数据采集

#### springboot

> springboot 好处：
>
> 1. 不需要那些繁琐重复的 xml 文件
> 2. 内嵌 Tomcat，不需要外部 Tomcat
> 3. 更方便的和各个第三方工具整合，只要维护一个配置文件即可（mysql、redis、es、dubbo、kafka）

> springboot 和 ssm 的关系
>
> springboot 整合了 springmvc，spring 等核心功能，也就是说本质还是原有的 spring，springmvc 的包，但是 springboot 单独包装了一层，用户不必直接对 springmvc，spring 等在 xml 中配置。

##### springboot分层：

掌握写数据接口

+ controller层：拦截用户请求，调用Service，响应请求
+ service层：调用 DAO，处理数据
+ DAO（使用 MyBatis 时称为 Mapper 层）：获取数据
+ 持久化层：存储数据

##### Controller code

```java
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

//@Controller //注解标明 Controller
@RestController //@Controller + @ResponseBody
public class LoggerController{
    @RequestMapping("test2")
    public String test2(@RequestParam("name") String nn,
                       @RequestParam("age", defaultValue = "18") int age){
        return "success" + name + age;
    }
    
    @RequestMapping("applog")
    public String test2(@RequestParam("param") String jsonStr){
        //sparkmall-mock：模拟生成数据模块
        //mock服务器不停的访问 http://pc_IP:8080/applog?jsonStr=* 产生原始数据
        
        return "success";
    }
}
```

