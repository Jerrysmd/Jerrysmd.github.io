---
title: "Data Warehouse: Real-Time" # Title of the blog post.
date: 2021-03-08T10:40:49+08:00 # Date of post creation.
description: "" # Description used for search engine.
featured: true # Sets if post is a featured post, making appear on the home page side bar.
draft: false # Sets whether to render this page. Draft of true will not be rendered.
toc: true # Controls if a table of contents should be generated for first-level links automatically.
# menu: main
# thumbnail: "images/.png" # Sets thumbnail image appearing inside card on homepage.
# featureImage: "/images/path/file.jpg" # Sets featured image on blog post.
# featureImageAlt: 'Description of image' # Alternative text for featured image.
# featureImageCap: 'This is the featured image.' # Caption (optional).
codeLineNumbers: true # Override global value for showing of line numbers within code block.
codeMaxLines: 40 # Override global value for how many lines within a code block before auto-collapsing.
codeLineNumbers: true # Override global value for showing of line numbers within code block.
figurePositionShow: true # Override global value for showing the figure label.
categories:
  - Technology
tags:
  - datawarehouse
  - distribution
  - flink
comments: true # Disable comment if false.

---

Data warehouse is a system that pulls together data derived from operational systems and external data sources within an organization for reporting and analysis. A data warehouse is a central repository of information that provides users with current and historical decision support information.

<!--more-->

## ODS 数据采集层

原始数据，日志和业务数据

### 日志数据采集

#### springboot

> springboot 好处：
>
> 1. 不需要那些繁琐重复的 xml 文件
> 2. 内嵌 Tomcat，不需要外部 Tomcat
> 3. 更方便的和各个第三方工具整合，只要维护一个配置文件即可（mysql、redis、es、dubbo、kafka）

> springboot 和 ssm 的关系
>
> springboot 整合了 springmvc，spring 等核心功能，也就是说本质还是原有的 spring，springmvc 的包，但是 springboot 单独包装了一层，用户不必直接对 springmvc，spring 等在 xml 中配置。

##### springboot分层

掌握写数据接口

+ controller层：拦截用户请求，调用Service，响应请求
+ service层：调用 DAO，处理数据
+ DAO（使用 MyBatis 时称为 Mapper 层）：获取数据
+ 持久化层：存储数据

##### SpringBoot 整合Kafka

```java
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

//@Controller //注解标明 Controller
@RestController //@Controller + @ResponseBody
@Slf4j //lombok中的包
public class LoggerController{
    @RequestMapping("test2")
    public String test2(@RequestParam("name") String nn,
                       @RequestParam("age", defaultValue = "18") int age){
        return "success" + name + age;
    }
    
    @Autowired //自动注入
    private KafkaTemplate<String, String> kafkaTemplate;
    
    @RequestMapping("applog")
    public String test2(@RequestParam("param") String jsonStr){
        //sparkmall-mock：模拟生成数据模块
        //mock服务器不停的访问 http://pc_IP:8080/applog?jsonStr=* 产生原始数据
        /*1.修改SpringBoot核心配置：
        	server.port=8081
        	指定kafka代理地址，可以多个：spring.kafka.bootstrap-servers=hadoop102.9092
        	指定消息key和消息体的编解码方式：
        		spring.kafka.producer.key-serializer=org.apache.kafka.common.serialization.StringSerilizer 
        		spring.kafka.producer.value-serializer=org.apache.kafka.common.serialization.StringSerilizer*/
        /*2.Resources中添加 logback.xml 配置文件：决定如何打印、落盘、打印哪些日志 ，类似log4j
        	在注释@Slf4j后，使用log.info(jsonStr);log.warn(jsonStr);log.debug();log.error();log.trace()*/
        /*3.自动注入kafkaTemplate，producer send 数据，打开zk、kk服务
        	运行kafka消费者：bin/kafka-console-consumer.sh --bootstrap-server hadoop102:9092 --topic ods_base_log*/
        kafkaTemplate.send("ods_base_log", jsonStr);
        return "success";
    }
}
```

##### 打包集群部署，Nginx 反向代理

> 简介：
>
> 高性能的 HTTP 和 反向代理服务器，特点是占有内存少，并发能力强，在同类型的网页服务器中表现较好。

> 反向代理和正向代理：
>
> 正向代理类似一个跳板机，代理访问外部资源，如 VPN。
>
> 反向代理是指以代理服务器来接受 internet 上的连接请求，然后将请求转发给内部网络上的服务器。

> Nginx 主要应用
>
> 1. 静态网站部署：Nginx 是一个 HTTP 的 web 服务器，可以将服务器上的静态文件（如 HTML、图片等）通过 HTTP 协议返回给浏览器客户端。
> 2. 负载均衡：如数据请求发到集群中不同的机器上，常用策略：轮询、权重、备机
> 3. 静态代理：把所有静态资源的访问改为访问 Nginx 而不是 Tomcat，Nginx 更擅长静态资源的处理。

### 业务数据采集

#### Flink-CDC

##### CDC

> Change Data Capture(变更数据获取)的简称，捕获增删改。

##### CDC的种类

CDC主要分为**基于查询**和**基于Binlog**两种方式

|                          | 基于查询                 | 基于Binlog               |
| ------------------------ | ------------------------ | ------------------------ |
| 开源产品                 | Sqoop、Kafka JDBC Source | Canal、Maxwell、Debezium |
| 执行模式                 | Batch                    | Streaming                |
| 是否可以捕获所有数据变化 | 否                       | 是                       |
| 延迟性                   | 高延迟                   | 低延迟                   |
| 是否增加数据库压力       | 是                       | 否                       |

##### Flink-cdc-connectors

可以直接从 MySQL、PostgreSQL等数据库直接 **读取全量数据**和**增量变更数据**的 source 组件

| 组件       | 业务流程                                     |
| ---------- | -------------------------------------------- |
| Flink：    | MySQL -> Canal -> kafka -> Flink -> 业务处理 |
| Flink-CDC: | MySQL -> Fink-CDC -> 业务处理                |

