// add custom js in this file
(function initGitalk(){
    var gitalk = new Gitalk({
      clientID: '38088090a241cbaeb071',
      clientSecret: '16ba1e7f011a6b6fbc6f857ada7909b6efcf81cc',
      repo: 'Jerrysmd.github.io',
      owner: 'Jerrysmd',
      admin: ['Jerrysmd'],
      id: location.pathname,      // Ensure uniqueness and length less than 50
      distractionFreeMode: true  // Facebook-like distraction free mode
    })
    
    gitalk.render('gitalk-container')
  })()