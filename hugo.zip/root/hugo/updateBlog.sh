#!/bin/bash
#echo "what did you update for your blog?"
#read CONTENT
echo '################################   '`date +%Y-%m-%d_%H:%M:%S` '   ################################'
cd /root/hugo
hugo --theme=hugo-clarity --baseUrl="https://Jerrysmd.github.io/"
cd public/
gitStatus=`git status`
[[ $gitStatus =~ "Changes not staged for commit" ]] && zip -qr hugo.zip /root/hugo/  -x "/root/hugo/public/*" -x "/root/hugo/themes/*"
git add -A
git commit -m "UPDATE"
git push origin master