#!/bin/bash
cd public
gitStatus=`git status`
echo "$gitStatus"
[[ $gitStatus =~ "Changes not staged for commit" ]] && echo "contains" 