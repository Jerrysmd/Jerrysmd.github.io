#!/bin/bash
cd themes/
mv hugo-clarity hugo-clarity.bak
git clone https://github.com/chipzoller/hugo-clarity --depth=1
