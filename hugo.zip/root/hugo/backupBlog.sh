#!/bin/bash
cd /home/jiarui/hugo/public/
rm hugo.zip
zip -qr hugo.zip /home/jiarui/hugo/  -x "/home/jiarui/hugo/public/*" -x "/home/jiarui/hugo/themes/*"
