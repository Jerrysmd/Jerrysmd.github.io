#!/bin/bash
#echo "what did you update for your blog?"
#read CONTENT
echo '################################   '`date +%Y-%m-%d_%H:%M:%S` '   ################################'
cd /home/jiarui/hugo/
hugo --theme=hugo-clarity --baseUrl="https://Jerrysmd.github.io/"
cd public/
zip -r hugo.zip /home/jiarui/hugo/  -x "/home/jiarui/hugo/public/*" -x "/home/jiarui/hugo/themes/*"
git add -A
git commit -m "UPDATE"
git push origin master
rm hugo.zip