---
title: "Data Warehouse: Behavior Collection" # Title of the blog post.
date: 2021-01-08T09:43:01+08:00 # Date of post creation.
description: "Article description." # Description used for search engine.
featured: true # Sets if post is a featured post, making appear on the home page side bar.
draft: false # Sets whether to render this page. Draft of true will not be rendered.
toc: false # Controls if a table of contents should be generated for first-level links automatically.
thumbnail: "images/distribution2.png" # Sets thumbnail image appearing inside card on homepage.
# featureImage: "/images/path/file.jpg" # Sets featured image on blog post.
# featureImageAlt: 'Description of image' # Alternative text for featured image.
# featureImageCap: 'This is the featured image.' # Caption (optional).
codeLineNumbers: true # Override global value for showing of line numbers within code block.
codeMaxLines: 40 # Override global value for how many lines within a code block before auto-collapsing.
codeLineNumbers: true # Override global value for showing of line numbers within code block.
figurePositionShow: true # Override global value for showing the figure label.
categories:
  - Technology
tags:
  - datawarehouse
  - distribution
comments: true # Disable comment if false.
---

Data warehouse is a system that pulls together data derived from operational systems and external data sources within an organization for reporting and analysis. A data warehouse is a central repository of information that provides users with current and historical decision support information.

<!--more-->

## 数据仓库

### 概念

+ 业务数据：

  处理事务过程中产生的数据。登录、下单、支付。

+ 用户行为数据：

  与客户端产品交互过程产生的数据。浏览、点击、停留。

![dataWarehouse_introduction](/post/20210108_dW_behavior_collection/dataWarehouse_introduction.png)

> 数仓是对数据进行 **备份、清洗、聚合、统计** 等操作。
>
> ODS原始数据层；DWD明细数据层；DWS服务数据层；DWT数据主题层；ADS数据应用层

### 技术组件

+ 数据采集传输：`Flume，Kafka，Sqoop`，Logstash，DataX
+ 数据存储：`MySQL，HDFS，HBASE`，Redis，MongoDB
+ 数据计算：`Hive，Tez，Spark`，Flink，Storm
+ 数据查询：`Presto，Kylin`，Impala，Druid
+ 数据可视化：Echarts、`Superset`、QuickBI、DataV
+ 任务调度：Azkaban、Oozie
+ 集群监控：Zabbix
+ 元数据管理：Atlas
+ 权限管理：Ranger

### 系统流程图

![system_design](/post/20210108_dW_behavior_collection/system_design.png)

+ `业务数据 / 前端 js 埋点行为数据：`持久化或不持久化写入数据库。

+ `Nginx：`负载均衡，使每个节点数据量保持合理。

+ `Flume：`采集日志。可以直接采集到 Hadoop，但 hadoop 可能处理很慢，如双11。可以先写到 Kafka 里。

  Flume 组成，Put 事务，Take 事务

  Flume 三个器：拦截器，选择器，监控器

  Flume 优化：内存，台数

+ `Kafka：`23 件事

  1.kafka基本信息 2.挂了 3.丢失 4.重复 5.积压 6.优化 7.高效读写的原因

+ `Zookeeper：`分布式协调

  1.部署多少台 2.选举机制，Paxos算法

+ `Flume：` 消费传到 Hadoop

+ `Hive：` 1.Hive内部表、外部表区别 2.4个by 3.系统函数 4.UDF、UDTF函数 5.窗口函数 6.Hive优化 7.数据倾斜 8.Hive引擎 9.元数据备份

### 集群配置

配置原则:

1. 消耗内存的组件要分开：HDFS 的 NameNode、Yarn 的 ResourceManager 分开配置
2. kafka、zk、flume 传输数据比较紧密的放在一起
3. 客户端放在一到两台服务器上，方便外部访问
