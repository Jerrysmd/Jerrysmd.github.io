#!/bin/bash
cd themes/
mv hugo-clarity hugo-clarity.bak
git clone https://github.com.cnpmjs.org/chipzoller/hugo-clarity
