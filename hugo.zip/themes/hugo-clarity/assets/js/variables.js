const featuredImageClass = 'image_featured';
const imageScalableClass = 'image-scalable';
const scaleImageClass = 'image-scale';
const pageHasLoaded = 'DOMContentLoaded';